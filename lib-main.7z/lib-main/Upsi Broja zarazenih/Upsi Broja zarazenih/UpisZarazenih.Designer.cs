﻿namespace Upsi_Broja_zarazenih
{
    partial class UpisZarazenih
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBrojZarazenih = new System.Windows.Forms.TextBox();
            this.txtUpisDatum = new System.Windows.Forms.TextBox();
            this.txtUpisSela = new System.Windows.Forms.TextBox();
            this.txtOIBZarazenih = new System.Windows.Forms.TextBox();
            this.txtPrezimeZarazenih = new System.Windows.Forms.TextBox();
            this.txtImeZarazenog = new System.Windows.Forms.TextBox();
            this.btnUpisZarazenih = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtBrojZarazenih);
            this.groupBox1.Controls.Add(this.txtUpisDatum);
            this.groupBox1.Controls.Add(this.txtUpisSela);
            this.groupBox1.Controls.Add(this.txtOIBZarazenih);
            this.groupBox1.Controls.Add(this.txtPrezimeZarazenih);
            this.groupBox1.Controls.Add(this.txtImeZarazenog);
            this.groupBox1.Controls.Add(this.btnUpisZarazenih);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(281, 249);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Upis zarazenih";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(166, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 38;
            this.label4.Text = "upis sela";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 13);
            this.label1.TabIndex = 37;
            this.label1.Text = "ime";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(166, 133);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 13);
            this.label6.TabIndex = 36;
            this.label6.Text = "Broj zarazenih";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(166, 77);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 13);
            this.label5.TabIndex = 35;
            this.label5.Text = "datum (mm,yyyy)";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 13);
            this.label3.TabIndex = 34;
            this.label3.Text = "OIB";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 33;
            this.label2.Text = "prezime";
            // 
            // txtBrojZarazenih
            // 
            this.txtBrojZarazenih.Location = new System.Drawing.Point(169, 149);
            this.txtBrojZarazenih.Name = "txtBrojZarazenih";
            this.txtBrojZarazenih.Size = new System.Drawing.Size(100, 20);
            this.txtBrojZarazenih.TabIndex = 32;
            this.txtBrojZarazenih.TextChanged += new System.EventHandler(this.txtBrojZarazenih_TextChanged);
            // 
            // txtUpisDatum
            // 
            this.txtUpisDatum.Location = new System.Drawing.Point(169, 93);
            this.txtUpisDatum.Name = "txtUpisDatum";
            this.txtUpisDatum.Size = new System.Drawing.Size(100, 20);
            this.txtUpisDatum.TabIndex = 31;
            this.txtUpisDatum.TextChanged += new System.EventHandler(this.txtUpisDatum_TextChanged);
            // 
            // txtUpisSela
            // 
            this.txtUpisSela.Location = new System.Drawing.Point(169, 41);
            this.txtUpisSela.Name = "txtUpisSela";
            this.txtUpisSela.Size = new System.Drawing.Size(100, 20);
            this.txtUpisSela.TabIndex = 30;
            this.txtUpisSela.TextChanged += new System.EventHandler(this.txtUpisSela_TextChanged);
            // 
            // txtOIBZarazenih
            // 
            this.txtOIBZarazenih.Location = new System.Drawing.Point(18, 149);
            this.txtOIBZarazenih.Name = "txtOIBZarazenih";
            this.txtOIBZarazenih.Size = new System.Drawing.Size(100, 20);
            this.txtOIBZarazenih.TabIndex = 29;
            this.txtOIBZarazenih.TextChanged += new System.EventHandler(this.txtOIBZarazenih_TextChanged);
            // 
            // txtPrezimeZarazenih
            // 
            this.txtPrezimeZarazenih.Location = new System.Drawing.Point(18, 93);
            this.txtPrezimeZarazenih.Name = "txtPrezimeZarazenih";
            this.txtPrezimeZarazenih.Size = new System.Drawing.Size(100, 20);
            this.txtPrezimeZarazenih.TabIndex = 28;
            this.txtPrezimeZarazenih.TextChanged += new System.EventHandler(this.txtPrezimeZarazenih_TextChanged);
            // 
            // txtImeZarazenog
            // 
            this.txtImeZarazenog.Location = new System.Drawing.Point(18, 41);
            this.txtImeZarazenog.Name = "txtImeZarazenog";
            this.txtImeZarazenog.Size = new System.Drawing.Size(100, 20);
            this.txtImeZarazenog.TabIndex = 27;
            this.txtImeZarazenog.TextChanged += new System.EventHandler(this.txtImeZarazenog_TextChanged);
            // 
            // btnUpisZarazenih
            // 
            this.btnUpisZarazenih.Location = new System.Drawing.Point(169, 175);
            this.btnUpisZarazenih.Name = "btnUpisZarazenih";
            this.btnUpisZarazenih.Size = new System.Drawing.Size(100, 62);
            this.btnUpisZarazenih.TabIndex = 26;
            this.btnUpisZarazenih.Text = "Upis ";
            this.btnUpisZarazenih.UseVisualStyleBackColor = true;
            this.btnUpisZarazenih.Click += new System.EventHandler(this.btnUpisZarazenih_Click);
            // 
            // UpisZarazenih
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(333, 300);
            this.Controls.Add(this.groupBox1);
            this.Name = "UpisZarazenih";
            this.Text = "Upis zarazenih";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBrojZarazenih;
        private System.Windows.Forms.TextBox txtUpisDatum;
        private System.Windows.Forms.TextBox txtUpisSela;
        private System.Windows.Forms.TextBox txtOIBZarazenih;
        private System.Windows.Forms.TextBox txtPrezimeZarazenih;
        private System.Windows.Forms.TextBox txtImeZarazenog;
        private System.Windows.Forms.Button btnUpisZarazenih;
    }
}