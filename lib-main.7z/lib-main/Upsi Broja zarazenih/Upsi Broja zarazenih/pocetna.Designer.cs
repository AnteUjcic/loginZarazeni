﻿namespace Upsi_Broja_zarazenih
{
    partial class pocetna
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPrikazZarazenih = new System.Windows.Forms.Button();
            this.btnUpisSela = new System.Windows.Forms.Button();
            this.btnUpisStanovnika = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnPrikazZarazenih
            // 
            this.btnPrikazZarazenih.Location = new System.Drawing.Point(82, 96);
            this.btnPrikazZarazenih.Name = "btnPrikazZarazenih";
            this.btnPrikazZarazenih.Size = new System.Drawing.Size(121, 94);
            this.btnPrikazZarazenih.TabIndex = 0;
            this.btnPrikazZarazenih.Text = "Prikaz zarazenih";
            this.btnPrikazZarazenih.UseVisualStyleBackColor = true;
            this.btnPrikazZarazenih.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnUpisSela
            // 
            this.btnUpisSela.Location = new System.Drawing.Point(209, 96);
            this.btnUpisSela.Name = "btnUpisSela";
            this.btnUpisSela.Size = new System.Drawing.Size(121, 94);
            this.btnUpisSela.TabIndex = 1;
            this.btnUpisSela.Text = "Upis sela";
            this.btnUpisSela.UseVisualStyleBackColor = true;
            this.btnUpisSela.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnUpisStanovnika
            // 
            this.btnUpisStanovnika.Location = new System.Drawing.Point(336, 96);
            this.btnUpisStanovnika.Name = "btnUpisStanovnika";
            this.btnUpisStanovnika.Size = new System.Drawing.Size(121, 94);
            this.btnUpisStanovnika.TabIndex = 2;
            this.btnUpisStanovnika.Text = "Upis stanovnika";
            this.btnUpisStanovnika.UseVisualStyleBackColor = true;
            this.btnUpisStanovnika.Click += new System.EventHandler(this.btnUpisStanovnika_Click);
            // 
            // pocetna
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(572, 315);
            this.Controls.Add(this.btnUpisStanovnika);
            this.Controls.Add(this.btnUpisSela);
            this.Controls.Add(this.btnPrikazZarazenih);
            this.Name = "pocetna";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.pocetna_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPrikazZarazenih;
        private System.Windows.Forms.Button btnUpisSela;
        private System.Windows.Forms.Button btnUpisStanovnika;
    }
}

