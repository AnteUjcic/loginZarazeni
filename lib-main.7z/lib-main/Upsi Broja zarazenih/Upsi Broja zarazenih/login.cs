﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using System.IO;
    
namespace Upsi_Broja_zarazenih
{   

    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        public string FromXMLusername = "";
        public string FromXMLPassword = "";

        private void Clear()
        {
            txtUsername.Clear();
            txtPassword.Clear();
        }
        private void txtUsername_TextChanged(object sender, EventArgs e)
        {


        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void login_Load(object sender, EventArgs e)
        {

        }

        private void txtPassword_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string user = txtUsername.Text;
            string lozinka = txtPassword.Text;

            XDocument doc = XDocument.Load(Application.StartupPath.ToString() + @"\users.xml");
            var odabraniKorisnik = from x in doc.Descendants("user").Where(x => (string)x.Element("username") == txtUsername.Text)
                                   select new
                                   {
                                       XMLuser = x.Element("username").Value,
                                       XMLpwd = x.Element("psw").Value,
                                   };

            foreach (var x in odabraniKorisnik)
            {
                FromXMLusername = x.XMLuser;
                FromXMLPassword = x.XMLpwd;
            }



            if (user == FromXMLusername)
            {
                if (lozinka == FromXMLPassword)
                {

                    MessageBox.Show("Uspjesno ulogirani");
                    pocetna pocetna = new pocetna();
                    pocetna.Show();



                }
                else
                {
                    MessageBox.Show("Netocno upisana lozinka");
                    Clear();
                }
            }
            else
            {
                MessageBox.Show("Netocno upisano ime");
                Clear();
            }
        }
    }
}
