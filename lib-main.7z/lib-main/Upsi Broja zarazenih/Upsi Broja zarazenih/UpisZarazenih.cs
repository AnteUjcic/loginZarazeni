﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.IO;
using System.Collections;

namespace Upsi_Broja_zarazenih
{
    public partial class UpisZarazenih : Form
    {
        List<Zarazeni> upisKList = new List<Zarazeni>();
        static string pathdocuments = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        static string xmlfile = "selo.xml";
        static string path = Path.Combine(pathdocuments, xmlfile);
        public UpisZarazenih()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void txtOIBZarazenih_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void txtPrezimeZarazenih_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtImeZarazenog_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUpisSela_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUpisDatum_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBrojZarazenih_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnUpisZarazenih_Click(object sender, EventArgs e)
        {
            Zarazeni zarazeni = new Zarazeni(
            txtImeZarazenog.Text,
            txtPrezimeZarazenih.Text,
            Convert.ToInt16(txtOIBZarazenih.Text),
            Convert.ToString(txtUpisDatum.Text),
            Convert.ToInt16(txtBrojZarazenih.Text),
            txtUpisSela.Text

            );
            upisKList.Add(zarazeni);
            try
            {
                var Selo = XDocument.Load(path);
                foreach (Zarazeni upisUXml in upisKList)
                {
                    var Sela = new XElement("Selo",
                        new XElement("Ime", upisUXml.Ime),
                        new XElement("Prezime", upisUXml.Prezime),
                        new XElement("OIB", upisUXml.OIB),
                        new XElement("Datum", upisUXml.DatumUpisa),
                        new XElement("Broj_zarazenih", upisUXml.BrojZarazenih)

                        );



                    Selo.Root.Add(Sela);

                }
                Selo.Save(path);
            }
            catch (Exception ex)
            {

                var Zarazeni = new XDocument();
                Zarazeni.Add(new XElement("Zarazeni"));
                foreach (Zarazeni upis in upisKList)
                {
                    var Sela = new XElement("Selo",
                           new XElement("Ime", upis.Ime),
                           new XElement("Prezime", upis.Prezime),
                           new XElement("OIB", upis.OIB),
                           new XElement("Datum", upis.DatumUpisa),
                           new XElement("Broj_zarazenih", upis.BrojZarazenih)
                  );

                    Zarazeni.Root.Add(Sela);
                }
                    Zarazeni.Save(path);
                }
            upisKList.Clear();
            this.Close();

            txtBrojZarazenih.Text = "";
            txtImeZarazenog.Text = "";
            txtOIBZarazenih.Text = "";
            txtPrezimeZarazenih.Text = "";
            txtUpisDatum.Text = "";
            txtUpisSela.Text = "";
            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
